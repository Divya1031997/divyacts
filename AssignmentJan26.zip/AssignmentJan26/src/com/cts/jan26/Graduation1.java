package com.cts.jan26;

import java.util.Scanner;

public class Graduation1 {

	public static void main(String[] args) {

		String studentName;
		int yearOfGraduation = 0;
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter your name:");
		
		while(!scanner.hasNext("[A-Za-z.!@#$%^&*]+"))
		{
			System.out.println("Please enter a valid name");
			scanner.next();
		}
		studentName=scanner.next();
		
		int c = 0;
		do {
			
			
		System.out.println("Enter your year of graduation:");
		
		try 
        { 
           
			yearOfGraduation =Integer.parseInt(scanner.next());
            c=0;
        }  
        catch (NumberFormatException e)  
        { 
            
        	System.out.println("Please enter a valid year"); 
            c++;
            
        } 
		}while(c!=0);
		
		System.out.println(studentName);
		System.out.println(yearOfGraduation);
		
		

	}

}
