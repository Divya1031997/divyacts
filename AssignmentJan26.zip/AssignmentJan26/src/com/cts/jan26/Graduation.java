package com.cts.jan26;

import java.util.Scanner;

public class Graduation {

	public static void main(String[] args) {
		
		String studentName;
		int yearOfGraduation;
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter your name:");
		studentName=scanner.next();
		
		System.out.println("Enter your year of graduation:");
		yearOfGraduation =Integer.parseInt(scanner.next());
		
		System.out.println("My name is "+studentName+". And I will graduate in "+yearOfGraduation+".");
		
		

	}

}
