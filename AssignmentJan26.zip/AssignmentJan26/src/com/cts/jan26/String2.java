package com.cts.jan26;

import java.util.Scanner;

public class String2 {
	public static void main(String args[]) {
	
	String string;
	Scanner scan=new Scanner(System.in);
	string=scan.nextLine();

}
}
